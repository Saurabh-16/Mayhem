/**
 * This is a client class which will take input and performs operations and will print the invoice
 */

package com.challenge.invoice;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class BillGenerateMachine {
	private static final String SPACE = " ";
	private static String name = "ABC";

	public static void main(String[] args) throws Exception {

		// Please uncomment the below code if want to read the input using
		// Scanner class from console

		/*
		 * 
		 * List<Items> item_list = new ArrayList<Items>(); // Reading the input
		 * from scanner Scanner input_details = new Scanner(System.in); String
		 * readItem = input_details.nextLine(); while ((readItem.length() > 0))
		 * { createItemObjectFromString(item_list, readItem); // Reading the
		 * next line readItem = input_details.nextLine(); }
		 * 
		 * Customer customer = new Customer(name, item_list);
		 * 
		 * // Print the bill in console
		 * System.out.println(customer.generateBill());
		 * 
		 */
	}

	// To be executed from test class

	public String generateBillForCustomer(List<String> inputItems) throws Exception {
		List<Items> item_list = new ArrayList<Items>();

		Iterator<String> it = inputItems.iterator();
		while (it.hasNext()) {

			String readItem = it.next();
			createItemObjectFromString(item_list, readItem);
		}

		Customer customer = new Customer(name, item_list);
		return customer.generateBill();

	}

	public static Items createItemObjectFromString(List<Items> item_list, String readItem) throws Exception {
		String[] item_details = readItem.split(SPACE);
		if (item_details.length < 3) {
			throw new IllegalArgumentException("Input Item is not in correct format");
		}
		int l1 = item_details[0].length();

		// Extracting the mid part of input excluding quantity and price
		readItem = readItem.substring(l1);
		readItem = readItem.replace(item_details[item_details.length - 1], SPACE);

		// Creating Item Object from Input String
		Items item = new Items(readItem, Integer.parseInt(item_details[0]),
				Float.parseFloat(item_details[item_details.length - 1]), null);

		// Checking if is contain pills so as to be considered for
		// tax_exemption
		if (readItem.contains("pills"))
			item.setItemType("MEDICAL");

		item_list.add(item);
		return item;
	}

}
