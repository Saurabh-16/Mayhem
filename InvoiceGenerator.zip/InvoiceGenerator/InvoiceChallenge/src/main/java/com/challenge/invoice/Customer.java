/**
 * This class will contain the customer information and items purchased
 */

package com.challenge.invoice;

import java.util.Iterator;
import java.util.List;

import javax.annotation.Nonnull;

public class Customer {

	private List<Items> itemPurchased;
	private String customer_name;

	// We need to pass list of items purchased by customer .
	// customer name is mandatory field
	public Customer(@Nonnull String name, List<Items> items) {
		this.customer_name = name;
		itemPurchased = items;
	}

	public String generateBill() {
		// Invoice is the final output return
		StringBuilder Invoice = new StringBuilder();
		double cost_peritem = 0;
		double sales_tax_peritem = 0;
		double total_sales_tax = 0;
		double total_cost = 0;

		// Iterate over item list passed from client class
		Iterator<Items> item_iterator = itemPurchased.iterator();
		while (item_iterator.hasNext()) {
			sales_tax_peritem = 0;
			Items item = item_iterator.next();
			if (item.isTaxExempted()) {
				cost_peritem = item.getQuantity() * item.getPrice();
			} else {
				sales_tax_peritem = item.getQuantity() * item.getPrice() * item.getTaxApplicable();
				cost_peritem = (item.getQuantity() * item.getPrice()) + sales_tax_peritem;
			}
			Invoice.append(item.toString() + Double.toString(cost_peritem) + "\n");
			total_cost += cost_peritem;
			total_sales_tax += sales_tax_peritem;

		}
		Invoice.append("\n");
		Invoice.append("Sales Taxes: " + total_sales_tax + "\n");
		Invoice.append("Total: " + total_cost + "\n");
		return Invoice.toString();

	}

}
