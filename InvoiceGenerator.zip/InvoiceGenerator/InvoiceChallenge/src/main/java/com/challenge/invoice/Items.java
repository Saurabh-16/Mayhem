/*
 * This class will contain all the details of the item.
 * Item Name , Item Quantity , Item Price ,Item Tax
 */


package com.challenge.invoice;
import javax.annotation.Nonnull;

public class Items {
	private final static double TAX_Applicable = 0.2;
	private final static String Tax_Exemption = "MEDICAL";
	
	private String item_name;
	private int quantity;
	private float price;
	private String itemType;
	
	public Items(@Nonnull String name,@Nonnull int quantity,@Nonnull float price,String itemType){
		this.item_name=name;
		this.quantity=quantity;
		this.price=price;
		this.itemType=itemType;
	}

	public String getName() {
		return item_name;
	}

	public void setName(String name) {
		this.item_name = name;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public double getTaxApplicable() {
		return TAX_Applicable;
	}
	
	public boolean isTaxExempted() {
		return(this.itemType!=null);
	}

	public String toString() {
		return  Integer.toString(this.getQuantity()) + "" + this.getName();
	}
}
