package com.challenge.invoice.test;

import java.util.ArrayList;

import org.junit.Test;

import com.challenge.invoice.BillGenerateMachine;
import com.challenge.invoice.Items;

import junit.framework.Assert;

public class TestItems {

	
	@Test
	public void test1() throws Exception {
		  String text = "1 bottle of wine: 20.00";
		  BillGenerateMachine generateMachine = new BillGenerateMachine();
		  Items item=  BillGenerateMachine.createItemObjectFromString(new ArrayList(), text);
		  System.out.println(item.getQuantity());
		  Assert.assertEquals("1", Integer.toString(item.getQuantity()));
	      Assert.assertEquals("bottle of wine:", item.getName().trim());
		  Assert.assertEquals("20.0", Float.toString(item.getPrice()));
		  Assert.assertNull("Item should not be classifies as Medical", item.getItemType());
		  
	}
	
	@Test
	public void test2() throws Exception {
		  String text = "2 box of headache pills: 4.00";
		  BillGenerateMachine generateMachine = new BillGenerateMachine();
		  Items item=  BillGenerateMachine.createItemObjectFromString(new ArrayList(), text);
		  System.out.println(item.getQuantity());
		  Assert.assertEquals("2", Integer.toString(item.getQuantity()));
	      Assert.assertEquals("box of headache pills:", item.getName().trim());
		  Assert.assertEquals("4.0", Float.toString(item.getPrice()));
		  Assert.assertNotNull("Item should be classifies as Medical", item.getItemType());
		  
	}
	
	

}
