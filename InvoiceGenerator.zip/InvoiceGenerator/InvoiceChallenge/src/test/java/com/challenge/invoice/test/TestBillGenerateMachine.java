package com.challenge.invoice.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.challenge.invoice.BillGenerateMachine;

import junit.framework.Assert;

public class TestBillGenerateMachine {
	
	
	private static final String  OutputCase1="1 bottle of wine:  24.0"+"\n"
                                     + "2 box of headache pills:  8.0"+"\n"
                                     + "1 box of pens:  12.0"+"\n"
                                     + "\n"
                                     +"Sales Taxes: 6.0"+"\n"
                                     +"Total: 44.0"+"\n";

	private static final String  OutputCase2="1 book:  36.0"+"\n"
                                         + "1 chocolate:  1.2"+"\n"
                                         + "\n"
                                         +"Sales Taxes: 6.2"+"\n"
                                         +"Total: 37.2"+"\n";

	
	
	
	
	@Test
	public void testInputCase1() throws Exception{
		List<String> itemDetails = new ArrayList<>();
		itemDetails.add("1 bottle of wine: 20.00");
		itemDetails.add("2 box of headache pills: 4.00");
	    itemDetails.add("1 box of pens: 10.00");
	    BillGenerateMachine generateBill = new BillGenerateMachine();
	    Assert.assertEquals(OutputCase1,  generateBill.generateBillForCustomer(itemDetails));
		
	}


	@Test
	public void testInputCase2() throws Exception{
		List<String> itemDetails = new ArrayList<>();
		itemDetails.add("1 book: 30");
		itemDetails.add("1 chocolate: 1");
	    BillGenerateMachine generateBill = new BillGenerateMachine();
	    Assert.assertEquals(OutputCase2,  generateBill.generateBillForCustomer(itemDetails));
		
	}

	}
